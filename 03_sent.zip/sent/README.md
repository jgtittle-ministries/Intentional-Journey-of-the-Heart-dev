# Sent — A Fellowship of the Heart Pilot

*Part of the Intentional Journey of the Heart (IJH) curriculum, developed by John G. Tittle and being piloted at Covenant Christian Academy of Warrenton in May 2026.*

## What this series is

Sent is the third movement of the IJH formation arc — twelve Tuesday evenings of communal calling discernment, equipping for the confirmed direction, and apostolic sending. It is the recognition of what the Spirit has already been doing across two prior series, and the communal sending of those He has formed.

Sent is open only to participants who completed both Getting Started and Going Deeper. The corporate-listening practices of Going Deeper Wks 7–8 are the architectural foundation; without that grounding, the Acts 13 protocol of the Sent discernment phase will not work.

The series sends each participant in the direction the body discerns the Spirit has been preparing in them. For some, that direction is starting a new formation group — the Vol 2 Exp 10 Level 5 architecture, the curriculum's most developed treatment of any calling. For others, it is a vocational deepening, a household formation season, a sustained third-place arc, a one-to-one accompaniment, or a hidden contemplative shape. The body honors each as a real calling.

**This is the renamed spring series.** Previously called "Going Out" in earlier curriculum drafts, the series has been renamed to "Sent" as part of the May 2026 calling-architecture broadening. The earlier draft sub-architecture called "Inviting Others" has been folded into the Sent Handbook Overview as the leadership-track sub-architecture within Sent.

## Contents of this bundle

### `01_handbook/` — Companion handbook + Overview

- **`IJH_Sent_Handbook_v2.docx`** — The full Companion handbook. Includes the broadened calling architecture, the Acts 13 sending discipline, the leadership-taxonomy as a worked-example for the leadership-track direction (parallel taxonomies for other directions are flagged but not yet developed), the spiritual-authority architecture, and the cohort-management section. Section 10 includes the new "Beyond Sent" subsection covering participants whose calling was not group-starting.
- **`IJH_Sent_HandbookOverview_v2.docx`** — The architectural-rationale overview. Section 4 names the broader calling shapes (group-starting, vocational, household, third-place, one-to-one, contemplative); Section 5 distinguishes the leadership-track 3-phase architecture from the broader 4-block sessions architecture; Section 7 broadens the discernment-gate decision to apply across all calling-shapes.

### `02_weekly-lessons/` — Twelve weekly Companion lesson plans

- Week 1 — Welcome Back (re-installation as a sent body; what changed at Going Deeper Wk 12)
- Week 2 — The Body Sent (what it means to be a sent body; not a sending agency)
- Week 3 — Where Am I Being Sent (each participant articulates a working sent-context sentence)
- Week 4 — Daily Tells (the daily noticing practice; the Spirit's specific direction in ordinary life)
- Week 5 — The Household Witness (Vol 1 Household Formation Law; for some, household IS the calling, for others, the household is the site)
- Week 6 — The Vocational Witness (Daniel and Joseph as paradigmatic; for some, vocational IS the calling, for others, the platform)
- Week 7 — The Third-Place Network (Eph 2:10; downhill/uphill mission distinction; the distinction propagates across all calling-shapes)
- Week 8 — Specific Missional Engagement (cohort-level discernment with three honest landings; Landing 2 is the architectural confirmation of differentiated callings)
- Week 9 — The Body Sent Beyond (mission far closes; the cost of yes is walked)
- Week 10 — What Sent Produced (individual integration; each member's calling-direction confirmed and named)
- Week 11 — Where the Cohort Lands (cohort-level five-level group-taxonomy assessment across the formation arc)
- Week 12 — Sending Into the Long Obedience (the closing Acts 13 commissioning; each participant sent by their confirmed direction)

*Note: The lesson plan filenames retain the `GO_` prefix as a stable tracking handle through the pilot. The internal content of each file says "Sent series" — only the filenames preserve the historical handle. After the pilot, the team can decide whether to rename the filenames as well.*

### `03_recurring-artifacts/` — Practices that continue across the series

- **`IJH_Family_Conversation_Cards.docx`** — Forty cards, ten in each Connect. Continued use through Sent.
- **`IJH_Rhythm_Card.docx`** — Daily / weekly / monthly rhythm. Continues across Sent and into the long obedience.
- **`IJH_Reading_List.docx`** — Annotated reading list for ongoing study.

## What changed in this version

The full calling-architecture broadening was applied at v2 in May 2026. The largest changes:

- The series was renamed from "Going Out" to "Sent."
- The Sent Handbook §1 now names the multiple legitimate downhill callings the body discerns — group-starting, vocational, household, third-place, one-to-one, contemplative — as architecturally honored, not as alternatives to leadership.
- The §1 series-outcomes list is now scoped to leadership-track-confirmed participants, with a paragraph naming that participants in non-leadership directions walk Sent toward different specific outcomes (parallel outcome-lists are flagged as undeveloped, with general pastoral wisdom as the team's working frame for non-leadership callings).
- The §4 Affective Taxonomy is named as a worked example for the leadership-track direction, not as the architecture for all callings.
- The §10 "Beyond Sent" section adds an explicit subsection for non-group-starting callings.
- The Re-Registration form's first question now asks about the calling-direction broadly, not just group-starting.
- GO Wk 5 (Household), Wk 6 (Vocational), Wk 7 (Third-Place), Wk 8 (Discernment), and Wk 10 (Integration) all include framing that honors the full calling-direction range.

## A flagged dependency the broadening surfaced

The Sent Handbook §9 (Phase Architecture) and the Sent Handbook Overview §5–6 still describe the leadership-track 3-phase architecture (Discernment / Equipping / Launch) as if it were the architecture of the actual session lessons. The actual session lessons follow a broader 4-block architecture (body sent / mission close-to-home / mission far / sending). This inconsistency is named in the v2 review's Section 4.6 and is left for the author to resolve before the pilot's spring 2027 cycle.

## Pilot status

This bundle is the v2 pilot edition. Field experience from the spring 2026 pilot will inform the v3 substantive rewrites (especially the Sent Handbook §9 architecture).

## License and reuse

The IJH curriculum is being piloted; reuse outside the pilot context should be discussed with John G. Tittle directly.

---

*Fellowship of the Heart — Sent series — Pilot edition v2, May 2026*
