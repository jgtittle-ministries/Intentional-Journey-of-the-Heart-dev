# Getting Started — A Fellowship of the Heart Pilot

*Part of the Intentional Journey of the Heart (IJH) curriculum, developed by John G. Tittle and being piloted at Covenant Christian Academy of Warrenton in May 2026.*

## What this series is

The Getting Started series is the entry point to the IJH formation arc. Ten Tuesday evenings, ninety minutes each (Week 10 runs 120 minutes — the Family Commissioning), walking the four Connects: with Self, with Others, with God, with Mission.

The series is open to individuals, parent-and-teen pairs, married couples, and other family units. The cohort runs as a single body of 8–18 participants across three age tracks — junior teens (12–14), senior teens (15–18), and parents — meeting in shared and split formations across the ten weeks.

Getting Started is not therapy, not Bible study, and not a program with a measurable outcome. It is formation work — teaching practices the participant carries into the rest of their life, whether or not they continue into the next series in the arc.

## Contents of this bundle

### `01_pre-cohort/` — On-ramp materials (4–8 weeks before Week 1)

- **`IJH_PreCohort_DiscernmentConversation_Guide_v1.docx`** — A 30-minute Companion-and-applicant conversation held 4 to 8 weeks before Week 1. Three blocks: 12 minutes of listening (four open questions), 12 minutes of naming (what Getting Started is and is NOT), 6 minutes of discernment (yes-and-ready / yes-but-not-yet / no-and-honest). Architecturally protects honest decline.

*Note: Three additional WP4 on-ramp materials — the Invitation Letter Template, the Family Pre-Cohort Worksheet, and the Companion Recruitment Language Guide — were developed alongside the PreCohort Guide but are not included in this bundle. They will be added in a subsequent release.*

### `02_handbook/` — Companion handbook

- **`IJH_GettingStarted_Handbook_FourConnects_v1.docx`** — The full Companion handbook for the series. Architectural overview, the Companion team's working frame, the four-Connects structure, container conditions, mandatory-reporting and pastoral-coverage protocols, and detailed run-sheet guidance.

### `03_weekly-lessons/` — Ten weekly Companion lesson plans

Each lesson plan contains: the Why-this-session paragraph, materials and setup checklist, detailed 90-minute run sheet (or 120-minute for Week 10), block-by-block scripts and notes, between-session practice, Companion team debrief prompts, and handouts (printed at the back of each lesson plan).

- Week 1 — Welcome (the four Connects, the container, and the discipline of beginning)
- Week 2 — Soil (the four soils of Mark 4; what kind of soil are you tonight?)
- Week 3 — Story (telling your story; the architecture of your interior)
- Week 4 — Known (the work of being known; honest pair work)
- Week 5 — Brave (entering the harder rooms of the heart)
- Week 6 — PROAPT (the prayer-rhythm practice)
- Week 7 — Garden (Connecting with God; the inner garden)
- Week 8 — Doubts (the doubts that surface as faith deepens)
- Week 9 — Mission (the four kinds of witness; downhill and uphill)
- Week 10 — Sending (the Family Commissioning; closing ritual)

### `04_recurring-artifacts/` — Practices that continue across the series and beyond

- **`IJH_Personal_Heart_Journal.docx`** — A 10-week companion journal for participants. Daily prompts, end-of-week reflections, free-write space. Private to the participant; the team does not collect.
- **`IJH_Family_Conversation_Cards.docx`** — Forty cards, ten in each Connect, for use at home between sessions. Designed for parent-and-teen pairs and family tables.
- **`IJH_Rhythm_Card.docx`** — A daily / weekly / monthly rhythm card distilling the practices into a sustainable long-term form. Begins after Getting Started; carries across the interlude into Going Deeper and beyond.
- **`IJH_Reading_List.docx`** — Annotated reading list for parents, teens, and the curious. Curated from Volume 5 of the IJH bibliography; not academic study, but the on-ramp.

## After Getting Started

Most participants will complete Getting Started and stop there; that is honest and good. For those who sense the Spirit calling them deeper, **Going Deeper** is the next series in the arc — twelve weeks, taken after a 6–10 week interlude. Going Deeper is invited but not assumed; the discernment to continue is the participant's, not the team's.

After Going Deeper, the **Sent** series is the third movement — twelve weeks of communal hearing, calling discernment, and apostolic sending. Sent is for participants whose calling the body discerns at a discernment point, whether that calling is to start a new formation group, to deepen vocationally or in the household, to walk a sustained third-place arc, to accompany one or two through a season, or to live a hidden contemplative shape.

## Pilot status

This bundle reflects the post-WP4 corpus state with the May 2026 calling-architecture broadening applied (the spring series renamed from "Going Out" to "Sent"). Files are all v1 or v2 pilot editions. Numbers, names, and pastoral-coverage details should be confirmed with the CCA team before Week 1.

## License and reuse

The IJH curriculum is being piloted; reuse outside the pilot context should be discussed with John G. Tittle directly.

---

*Fellowship of the Heart — Getting Started series — Pilot edition, May 2026*
