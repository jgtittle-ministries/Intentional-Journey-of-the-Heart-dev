# Going Deeper — A Fellowship of the Heart Pilot

*Part of the Intentional Journey of the Heart (IJH) curriculum, developed by John G. Tittle and being piloted at Covenant Christian Academy of Warrenton in May 2026.*

## What this series is

The Going Deeper series is the second movement of the IJH formation arc. Twelve Tuesday evenings, ninety minutes each, taken after a 6–10 week interlude that follows Getting Started.

Where Getting Started introduced the four Connects as practices, Going Deeper deepens them into the architectural work of the soul — the soils that grow or choke formation, the knots in the heart that the four-Connects work surfaces, corporate listening as a body, the Spirit speaking to the group about itself, the shadow mission, and the discernment of calling at Acts 13.

Going Deeper is open only to participants who completed Getting Started. The discernment to continue — through the interlude — is the participant's; the cohort that gathers at GD Wk 1 is a continuation cohort, not a new admission round.

## Contents of this bundle

### `01_handbook/` — Companion handbooks

- **`GD_Handbook_v1_2_Master.docx`** — The full Master Companion handbook for the series. Includes the integrated v1.2 Addenda (formerly a separate file, now Appendix G) and the Continuous-Run Architecture appendix (Appendix H, with CCA Pilot Calendar template).
- **`GD_Handbook_Addenda_v1_2_DEPRECATED.docx`** — The original Addenda file, now deprecated. Content has been merged into the Master as Appendix G; this file is retained with a deprecation banner for historical reference.

### `02_weekly-lessons/` — Twelve weekly Companion lesson plans

- Week 1 — Welcome Back (re-installation as a body; what carried across the interlude)
- Week 2 — Soils (Mark 4 deepened; the soil of one's own heart in this season)
- Week 3 — Knots (the four knot types from Vol 2 Exp 2; recognizing them in oneself and the cohort)
- Week 4 — Co-Processing (pair work as confession-companions; the discipline of carrying without fixing)
- Week 5 — Confession (the harder rooms; James 5 in cohort; healing through naming)
- Week 6 — PROAPT (the prayer-rhythm practice deepened; the Spirit's specific direction)
- Week 7 — Corporate Listening (the cohort listens together for one Bringer's question)
- Week 8 — The Group Hears Itself (the cohort listens about itself; what the Spirit is saying about the body)
- Week 9 — Shadow Mission (the gift's shadow direction; downhill / uphill from Vol 2 Exp 5)
- Week 10 — Calling Discernment (the Acts 13 paradigm enacted for ONE cohort member whose calling is at a discernment point; the Discerner's calling can take many shapes — group-starting, vocational, household, third-place, one-to-one, contemplative)
- Week 11 — Where Is Our Cohort? (the body's honest five-level group-taxonomy assessment)
- Week 12 — Sending and Bridge (closing the formation arc's middle movement; bridge to Sent for those continuing; bridge to long obedience for those not)

### `03_recurring-artifacts/` — Practices that continue across the series

- **`IJH_Family_Conversation_Cards.docx`** — Forty cards, ten in each Connect. Continued use through GD.
- **`IJH_Rhythm_Card.docx`** — Daily / weekly / monthly rhythm. The rhythm built in Getting Started is sustained across GD; the card is the durable practice form.
- **`IJH_Reading_List.docx`** — Annotated reading list for ongoing study during GD and the interludes.

## What changed in this version

The Wk 10 Calling Discernment lesson now explicitly names the range of callings the Discerner could be bringing — group-starting is named alongside vocational deepening, household formation, third-place arc, one-to-one accompaniment, and contemplative directions. The Acts 13 architecture is the same regardless of which direction the Spirit confirms.

The Wk 12 closing bridge has been updated to honor participants whose calling has been confirmed in non-leadership directions. They are not "non-continuers"; they are sent differently.

The Master Handbook Section 10 spoken-bridge language reflects the same broadening.

## After Going Deeper

For those whose discernment at Wk 10 surfaces a calling at a decision-point, **Sent** is the next series — twelve weeks of communal calling discernment, equipping for the confirmed direction, and apostolic sending. Sent admits only participants who completed both Getting Started and Going Deeper.

For those whose calling does not require Sent's cohort structure, the Wk 12 sending and the Rhythm Card practice carry the long obedience forward.

## Pilot status

This bundle reflects the post-WP4 corpus state with the May 2026 calling-architecture broadening applied. The spring-series name changed from "Going Out" to "Sent"; this rename has been propagated through all GD materials.

## License and reuse

The IJH curriculum is being piloted; reuse outside the pilot context should be discussed with John G. Tittle directly.

---

*Fellowship of the Heart — Going Deeper series — Pilot edition, May 2026*
